package com.noonpay.qa.common.builder;

import java.util.Properties;

public interface PropertiesProcessor {
	Properties process(Properties in);
}
