package com.noonpay.qa.common.exceptions;

public class NegativeRequestIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -816055087071476033L;

	public NegativeRequestIdNotFoundException() {
		super("");
	}
}
