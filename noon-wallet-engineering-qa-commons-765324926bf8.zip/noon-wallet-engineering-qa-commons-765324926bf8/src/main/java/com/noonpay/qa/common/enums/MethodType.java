package com.noonpay.qa.common.enums;

public enum MethodType {
   get,post,put,delete;
}
