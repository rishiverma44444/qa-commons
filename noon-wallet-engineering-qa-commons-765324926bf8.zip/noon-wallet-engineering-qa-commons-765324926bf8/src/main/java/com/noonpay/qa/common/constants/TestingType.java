package com.noonpay.qa.common.constants;

public class TestingType {

	public static final String COMPONENT = "component";
	public static final String INTEGRATION = "integration";
	public static final String SANITY = "sanity";

}
