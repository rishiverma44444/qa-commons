package com.noonpay.qa.common.enums;

public enum ServiceName {
    campaign,recharge,wallet,pos,p2p,merchantgateway;
}
